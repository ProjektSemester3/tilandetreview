#include "wrong_bottle.h"
#include "ui_wrong_bottle.h"

wrong_bottle::wrong_bottle(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::wrong_bottle)
{
    ui->setupUi(this);
}

wrong_bottle::~wrong_bottle()
{
    delete ui;
}

void wrong_bottle::on_pushButton_clicked()
{
    this->close();

}

void wrong_bottle::on_pushButton_2_clicked()
{
    this->close();
}
