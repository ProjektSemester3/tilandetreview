#include <pthread.h>
#include <iostream>

class scopedLocker
{
public:
  scopedLocker(pthread_mutex_t* mutex_):mutex(mutex)
  {
    pthread_mutex_lock(mutex);
  };

  ~scopedLocker()
  {
    pthread_mutex_unlock(mutex);
  };

private:
  pthread_mutex_t* mutex;
};
