#ifndef IN_PROGRESS_H
#define IN_PROGRESS_H

#include <QDialog>

namespace Ui {
class in_progress;
}

class in_progress : public QDialog
{
    Q_OBJECT

public:
    explicit in_progress(QWidget *parent = 0);
    ~in_progress();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::in_progress *ui;
};

#endif // IN_PROGRESS_H
