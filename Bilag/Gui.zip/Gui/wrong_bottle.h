#ifndef WRONG_BOTTLE_H
#define WRONG_BOTTLE_H

#include <QDialog>

namespace Ui {
class wrong_bottle;
}

class wrong_bottle : public QDialog
{
    Q_OBJECT

public:
    explicit wrong_bottle(QWidget *parent = 0);
    ~wrong_bottle();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::wrong_bottle *ui;
};

#endif // WRONG_BOTTLE_H
