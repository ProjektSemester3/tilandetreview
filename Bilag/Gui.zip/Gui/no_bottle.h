#ifndef NO_BOTTLE_H
#define NO_BOTTLE_H

#include <QDialog>

namespace Ui {
class no_bottle;
}

class no_bottle : public QDialog
{
    Q_OBJECT

public:
    explicit no_bottle(QWidget *parent = 0);
    ~no_bottle();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::no_bottle *ui;
};

#endif // NO_BOTTLE_H
