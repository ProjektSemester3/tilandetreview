#include "countthread.h"
#include <QtCore>
#include "readwrite.h"
#define PSOC "/dev/psoc_5"
#define GET_STATUS 0x00
#define OPEN_BOTTLE '0x05'


void CountThread::run()
{


    int min=min_+(hours_*60);

    for(int i=0; i<min+1;i++)
    {
        QMutex mutex;
        mutex.lock();
        if(this->stop) break;
        mutex.unlock();

        emit numberChanged(min-i);
        this->msleep(100);
    }
}

void CountThread::setMin(int min)
{
  min_=min;
}
void CountThread::setHours(int hours)
{
  hours_=hours;
}
