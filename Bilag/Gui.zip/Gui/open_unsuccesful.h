#ifndef OPEN_UNSUCCESFUL_H
#define OPEN_UNSUCCESFUL_H

#include <QDialog>

namespace Ui {
class open_unsuccesful;
}

class open_unsuccesful : public QDialog
{
    Q_OBJECT

public:
    explicit open_unsuccesful(QWidget *parent = 0);
    ~open_unsuccesful();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::open_unsuccesful *ui;
};

#endif // OPEN_UNSUCCESFUL_H
