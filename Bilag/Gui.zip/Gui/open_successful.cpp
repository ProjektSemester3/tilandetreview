#include "open_successful.h"
#include "ui_open_successful.h"

open_successful::open_successful(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::open_successful)
{
    ui->setupUi(this);
}

open_successful::~open_successful()
{
    delete ui;
}

void open_successful::on_pushButton_clicked()
{
    this->close();
}

void open_successful::on_pushButton_2_clicked()
{
    this->close();
}
