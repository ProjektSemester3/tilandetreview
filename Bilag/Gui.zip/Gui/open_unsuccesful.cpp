#include "open_unsuccesful.h"
#include "ui_open_unsuccesful.h"

open_unsuccesful::open_unsuccesful(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::open_unsuccesful)
{
    ui->setupUi(this);
}

open_unsuccesful::~open_unsuccesful()
{
    delete ui;
}

void open_unsuccesful::on_pushButton_clicked()
{
    this->close();
}

void open_unsuccesful::on_pushButton_2_clicked()
{
    this->close();
}
