#ifndef READWRITEVIRTUAL
#define READWRITEVIRTUAL
#define PSOC "/home/stud/workspace/Gui/psoccmd.txt"


class ReadWriteVirtual
{
public:
    ReadWriteVirtual(){}

    void writeVirtual(int cmd)
    {
        FILE *fd;
        int buff[2];
        fd = fopen(PSOC, "r+");
        buff[0]=cmd;
        fwrite(buff,1,2,fd);
        fclose(fd);
    }

    int readVirtual()
    {
        FILE *fd;
        int buff[2];
        fd = fopen(PSOC, "r+");
        fread(buff,2,1,fd);
        fclose(fd);
        return buff[0];
    }


};

#endif // READWRITEVIRTUAL

