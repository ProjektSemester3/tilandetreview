#ifndef READWRITE_H
#define READWRITE_H
#include <cstdio>
#define PSOC "/dev/psoc_1"

class ReadWrite
{
public:
    ReadWrite();
    void cmdwrite(int cmd)
    {
        FILE *fd;
        char buff[2];
        fd = fopen(PSOC, "r+");
        buff[0]=cmd;
        buff[1] = '\0';
        fwrite(buff,1,2,fd);
        fclose(fd);
    }

    int cmdread()
    {
        FILE *fd;
        int buff[2];
        fd = fopen(PSOC, "r+");
        fread(buff,2,1,fd);
        fclose(fd);
        return buff[0];
    }

private:
};

#endif // READWRITE_H
