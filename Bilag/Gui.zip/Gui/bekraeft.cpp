#include "bekraeft.h"
#include "ui_bekraeft.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"

Bekraeft::Bekraeft(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Bekraeft)
{
    ui->setupUi(this);
}

Bekraeft::~Bekraeft()
{
    delete ui;
}

void Bekraeft::on_pushButton_clicked()
{
    this->close();
}

void Bekraeft::on_pushButton_2_clicked()
{

}
