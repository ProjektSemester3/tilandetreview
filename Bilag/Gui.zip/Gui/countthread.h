#ifndef COUNTTHREAD_H
#define COUNTTHREAD_H

#include <QThread>



class CountThread: public QThread
{
    Q_OBJECT
public:
    explicit CountThread(QObject *parent = 0):QThread(parent)
    {
        stop = false;
    }
    void run();
    void setMin(int min);
    void setHours(int hours);
    bool stop;

signals:
    void numberChanged(int min);

public slots:

private:
    int hours_;
    int min_;
};

#endif // COUNTTHREAD_H
