#include "in_progress.h"
#include "ui_in_progress.h"

in_progress::in_progress(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::in_progress)
{
    ui->setupUi(this);
}

in_progress::~in_progress()
{
    delete ui;
}

void in_progress::on_pushButton_clicked()
{
    this->close();
}

void in_progress::on_pushButton_2_clicked()
{
    this->close();
}
