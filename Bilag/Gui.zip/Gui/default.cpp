#include "default.h"
#include "ui_default.h"

Default::Default(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Default)
{
    ui->setupUi(this);
}

Default::~Default()
{
    delete ui;
}

void Default::on_pushButton_clicked()
{
    this->close();
}

void Default::on_pushButton_2_clicked()
{
    this->close();
}
