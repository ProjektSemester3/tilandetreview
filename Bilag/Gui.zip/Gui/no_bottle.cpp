#include "no_bottle.h"
#include "ui_no_bottle.h"

no_bottle::no_bottle(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::no_bottle)
{
    ui->setupUi(this);
}

no_bottle::~no_bottle()
{
    delete ui;
}

void no_bottle::on_pushButton_clicked()
{
    this->close();
}

void no_bottle::on_pushButton_2_clicked()
{
    this->close();
}
