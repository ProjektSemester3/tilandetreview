#ifndef OPEN_SUCCESSFUL_H
#define OPEN_SUCCESSFUL_H

#include <QDialog>

namespace Ui {
class open_successful;
}

class open_successful : public QDialog
{
    Q_OBJECT

public:
    explicit open_successful(QWidget *parent = 0);
    ~open_successful();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::open_successful *ui;
};

#endif // OPEN_SUCCESSFUL_H
