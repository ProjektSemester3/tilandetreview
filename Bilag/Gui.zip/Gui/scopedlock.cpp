#include "scopedlock.h"

scopedLock::scopedLock()
{

}

