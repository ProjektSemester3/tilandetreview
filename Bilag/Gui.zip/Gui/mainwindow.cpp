#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <linux/rtc.h>
#include <string>
#include <QThread>
#include <QDateTime>
#include <QtCore>
#include "readwrite.h"
#include "readwritevirtual.h"
#include <QMessageBox>
#include <iostream>

using namespace std;
pthread_mutex_t mut=PTHREAD_MUTEX_INITIALIZER;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->label->hide();
    ui->bekraeft->hide();
    ui->comboBox->hide();
    ui->comboBox_2->hide();


   /* ui->pushButton_5->setStyleSheet("background-image: url(/home/stud/Desktop/Gui/Planlaeg_Aabning.PNG)");
    ui->pushButton_3->setStyleSheet("background-image: url(/home/stud/Desktop/Gui/Aaben_nu.PNG)");
    ui->pushButton_7->setStyleSheet("background-image: url(/home/stud/Desktop/Gui/WineBook.PNG)");*/
    ui->tilbage->hide();
    thread = new CountThread(this);
    connect(thread,SIGNAL(numberChanged(int)),this,SLOT(onNumberChanged(int)));
    threadRunning_ = false;
    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()),this,SLOT(timerFunction()));
    timer->start(1000);
    ui->timer->hide();
    ui->min->hide();
}


MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::hideMainMenu()
{
    ui->aabenNu->hide();;
    ui->planlaegAabning->hide();
}



void MainWindow::on_tilbage_clicked()
{
    ui->label->hide();
    ui->bekraeft->hide();
    ui->aabenNu->show();
    ui->planlaegAabning->show();
    ui->tilbage->hide();
    ui->comboBox->hide();
    ui->comboBox_2->hide();
    ui->label_2->show();
    ui->label_3->show();
    ui->label_4->show();
    ui->label_5->show();
    ui->timer->hide();
    ui->min->hide();


}

void MainWindow::showPlanlaegMenu()
{
    ui->label->show();
    ui->bekraeft->show();
    ui->tilbage->show();
    ui->comboBox->show();
    ui->comboBox_2->show();
    ui->min->show();
    ui->timer->show();
}

void MainWindow::on_planlaegAabning_clicked()
{
    hideMainMenu();
    showPlanlaegMenu();
}


void MainWindow::onNumberChanged(int min)
{
    int hours=min/60;
    int minuttes=min-(hours*60);


    QString smin = QString::number(minuttes);
    QString shour = QString::number(hours);

    ui->label_3->setText(shour);
    ui->label_5->setText(smin);
    if(min == 0)
    {
        on_aabenNu_clicked();
    }

}





void MainWindow::on_bekraeft_clicked()
{
    thread->stop = false;
    thread->setMin(min_);
    thread->setHours(hour_);
    if(threadRunning_ == false)
    {
        thread->start();
        threadRunning_ = true;
    }
    else if(threadRunning_ == true)
    {
        thread->stop = true;
        threadRunning_ = false;
    }
}

void MainWindow::on_comboBox_2_activated(int index)
{

        hour_=index;
}



void MainWindow::on_comboBox_activated(int index)
{
    min_=index*10;
}

void MainWindow::on_aabenNu_clicked()
{
    int OpenBottle = 5;
    int InvalidType = 21;
    int ValidType = 14;
    int NoBottle = 22;

    ReadWriteVirtual obj;
    obj.writeVirtual(NoBottle);
    int buff=obj.readVirtual();
    cout << buff<< endl;

    for(;;)
        {


            if(buff==ValidType)
            {
                QMessageBox::information(this,tr("Message"), tr("Godkendt flaske.\n Starter process..."));
                cout << "test valid type" << endl;
                break;
            }

            else if(buff==InvalidType)
            {
                QMessageBox::information(this,tr("Message"), tr("Vinflaske ugyldig."));
                cout << "test invalid type" << endl;
                break;
            }

            else if(buff==NoBottle)
            {
                QMessageBox::information(this,tr("Message"), tr("Ingen flaske registreret."));
                cout << "test noBottle" << endl;
                break;
            }

        }

}


void MainWindow::timerFunction()
{

    QTime time = QTime::currentTime();
    QString time_text = time.toString("hh : mm : ss");

    ui->label_6->setText(time_text);

}


void MainWindow::on_stop_clicked()
{
    ui->bekraeft->show();
}
