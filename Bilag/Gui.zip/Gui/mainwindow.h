#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTimer>
#include "countthread.h"

namespace Ui {
class MainWindow;
}
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void hideMainMenu();
    void showPlanlaegMenu();
    int getHour();
    int getMin();
    void* countDown(void*);
    void* showTime(void*);
    CountThread* thread;

public slots:
    void onNumberChanged(int);
    void timerFunction();

private slots:
    //on_dateTimeEdit_dateChanged(const QDate &date);
    void on_planlaegAabning_clicked();

    void on_bekraeft_clicked();

    void on_aabenNu_clicked();

    void on_tilbage_clicked();

    void on_comboBox_2_activated(int index);

    void on_comboBox_activated(int index);


    void on_stop_clicked();

private:
    Ui::MainWindow *ui;
    int hour_=0;
    int min_;
    bool threadRunning_;
    QTimer *timer;

};

#endif // MAINWINDOW_H
