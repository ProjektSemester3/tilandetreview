#ifndef BEKRAEFT_H
#define BEKRAEFT_H

#include <QDialog>

namespace Ui {
class Bekraeft;
}

class Bekraeft : public QDialog
{
    Q_OBJECT

public:
    explicit Bekraeft(QWidget *parent = 0);
    ~Bekraeft();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::Bekraeft *ui;
};

#endif // BEKRAEFT_H
